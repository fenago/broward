<div class="site-info">
	<?php get_template_part( 'template-parts/footer/site', 'name' ); ?>
	<?php get_template_part( 'template-parts/footer/privacy', 'policy' ); ?>
</div><!-- .site-info -->
