<header id="masthead" class="fse-template-part fse-header entry-content">
	<?php
		$template = new A8C\FSE\WP_Template();
		$template->output_template_content( A8C\FSE\WP_Template::HEADER );
	?>
</header>
